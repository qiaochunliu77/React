import * as actionTypes from './constants';

const defaultState = {
    recommendList:[]
}
export default (state = defaultState, action) => {
    switch(action.type) {
        default:
            return state
    }
}